package intermediarios;

/**
 *
 * @author Vagner
 */
public class ConsultarCliente {
    
}
